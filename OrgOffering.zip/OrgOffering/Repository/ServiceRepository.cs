﻿using OrgOffering.Data;
using OrgOffering.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OrgOffering.Repository
{
    public class ServiceRepository
    {
    
            protected readonly CMPG323Context _context = new CMPG323Context();

            // GET ALL: Service
            public IEnumerable<Service> GetAll()
            {
                return _context.Service.ToList();
            }

            // TO DO: Add ‘Get By Id’
            // TO DO: Add ‘Create’
            // TO DO: Add ‘Edit’
            // TO DO: Add ‘Delete’
            // TO DO: Add ‘Exists’

            // GET BY ID: Service
            public Service GetById(Guid id)
              {
                  return _context.Service.FirstOrDefault(s => s.ServiceId == id);
              }

              // CREATE: Service
              public void Create(Service service)
              {
                  service.ServiceId = Guid.NewGuid();
                  _context.Add(service);
                  _context.SaveChanges();
              }

              // EDIT: Service
              public void Edit(Service service)
              {
                  _context.Update(service);
                  _context.SaveChanges();
              }

              // DELETE: Service
              public void Delete(Guid id)
              {
                  var service = GetById(id);
                  if (service != null)
                  {
                      _context.Remove(service);
                      _context.SaveChanges();
                  }
              }

              // EXISTS: Service
              public bool Exists(Guid id)
              {
                  return _context.Service.Any(s => s.ServiceId == id);
              }
        }
    }





