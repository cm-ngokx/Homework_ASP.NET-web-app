﻿using OrgOffering.Data;
using OrgOffering.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OrgOffering.Repository
{
    public class ProductRepository
    {
        protected readonly CMPG323Context _context = new CMPG323Context();

        // GET ALL: Products
        public IEnumerable<Product> GetAll()
        {
            return _context.Product.ToList();
        }

        // TO DO: Add ‘Get By Id’
        // TO DO: Add ‘Create’
        // TO DO: Add ‘Edit’
        // TO DO: Add ‘Delete’
        // TO DO: Add ‘Exists’

        // GET BY ID: Product
          public Product GetById(Guid id)
          {
              return _context.Product.FirstOrDefault(s => s.ProductId == id);
          }

          // CREATE: Service
          public void Create(Product product)
          {
            product.ProductId = Guid.NewGuid();
              _context.Add(product);
              _context.SaveChanges();
          }

          // EDIT: Service
          public void Edit(Product product)
          {
              _context.Update(product);
              _context.SaveChanges();
          }

          // DELETE: Service
          public void Delete(Guid id)
          {
              var service = GetById(id);
              if (service != null)
              {
                  _context.Remove(service);
                  _context.SaveChanges();
              }
          }

          // EXISTS: Service
          public bool Exists(Guid id)
          {
              return _context.Service.Any(s => s.ServiceId == id);
          }
    }
}


